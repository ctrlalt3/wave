import Combine
import LocalAuthentication
import SwiftUI
import UIKit

@MainActor
final class WaveAppAccess: ObservableObject {
    @Published private(set) var unlocked = false
    @Published private(set) var authenticating = false
    @Published private(set) var message: String?
    private var context: LAContext?
    private var generation = UUID()
    private var attempted = false
    func lock() {
        generation = UUID(); context?.invalidate(); context = nil
        unlocked = false; authenticating = false; attempted = false
    }
    func authenticate(automatic: Bool = false) async {
        guard UIApplication.shared.applicationState == .active, !authenticating, !unlocked, !automatic || !attempted else { return }
        attempted = true; authenticating = true; message = nil
        let ticket = generation
        let context = LAContext(); self.context = context
        context.localizedCancelTitle = "Cancelar"
        var failure: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &failure) else {
            message = "Configura Face ID, Touch ID o un código del dispositivo para entrar en Wave."
            authenticating = false; return
        }
        do {
            let accepted = try await context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "Desbloquear Wave para entrar en la app.")
            guard ticket == generation else { return }
            unlocked = accepted; authenticating = false
            if !accepted { message = "No se pudo desbloquear Wave." }
        } catch {
            guard ticket == generation else { return }
            authenticating = false; message = "Wave sigue bloqueada. Puedes intentarlo de nuevo."
        }
    }
}
@MainActor
struct WaveAuthenticatedShell<Content: View>: View {
    @StateObject private var access = WaveAppAccess()
    @Environment(\.scenePhase) private var phase
    @ViewBuilder let content: () -> Content
    var body: some View {
        ZStack {
            WaveTheme.background.ignoresSafeArea()
            if access.unlocked { content() }
            else {
                VStack(spacing: 20) {
                    Image(systemName: "lock.fill").font(.largeTitle)
                    Text("Wave").font(.title.weight(.semibold))
                    Text("Desbloquea para entrar en la app. Los controles de música no usan este bloqueo.")
                        .font(.subheadline).foregroundStyle(WaveTheme.secondary).multilineTextAlignment(.center)
                    Button { Task { await access.authenticate() } } label: {
                        Label(access.authenticating ? "Desbloqueando…" : "Entrar", systemImage: "faceid").frame(minHeight: 44)
                    }.buttonStyle(.borderedProminent).disabled(access.authenticating)
                    if let message = access.message { Text(message).font(.caption).foregroundStyle(WaveTheme.secondary) }
                }.padding(28).frame(maxWidth: 420)
            }
            if phase != .active { WaveTheme.background.ignoresSafeArea() }
        }.task { await access.authenticate(automatic: true) }
            .onChange(of: phase) { _, value in
                if value == .background { access.lock() }
                else if value == .active { Task { await access.authenticate(automatic: true) } }
            }
    }
}
